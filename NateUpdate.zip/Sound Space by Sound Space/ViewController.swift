//
//  ViewController.swift
//  Sound Space by Code Space
//
//
//  Created by Taylor LeBlanc, Nathan Robinson, Tyler Creller, Daniel Ford, Shai Ben-Dor on 2/4/15.
//  Copyright (c) 2015 Sound Space. All rights reserved.
//
//

import UIKit
import Foundation

class ViewController: UIViewController, UIPickerViewDelegate {
    /*******************************************************************************
    // Class: ViewController
    // Last modified: 2/5/2015
    //
    // songNameField : User entered song name
    // artistField : User entered artist name
    // albumField : User entered album name
    // composerField : User entered composer name
    // lengthSlider : User control for length of the song
    // lengthLabel : Label to display the length of the song
    // yearStepper : User controlled to change the year the song was made
    // yearLabel: Label to display the year the song was made
    // theSongModel: Shared instance of all songs, see sharedSongModel.swift
    ******************************************************************************/
    
    @IBOutlet weak var songNameField : UITextField!
    @IBOutlet weak var artistField : UITextField!
    @IBOutlet weak var albumField : UITextField!
    @IBOutlet weak var composerField : UITextField!
    @IBOutlet weak var lengthSlider : UISlider!
    @IBOutlet weak var lengthLabel : UILabel!
    @IBOutlet weak var yearStepper : UIStepper!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var artistView : UITextView!
    @IBOutlet weak var songView : UITextView!
    @IBOutlet weak var removeSong : UITextField!
    @IBOutlet weak var findSongBy : UITextField!
    @IBOutlet weak var playlistSwitch: UISwitch!
    @IBOutlet weak var pickerView: UIPickerView!

    
    var theSongModel: sharedSongModel = sharedSongModel.theSharedSongModel
    
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 24, 2015
    function refreshUI
    purpose - Reset and reload componenents in the view
    parameters - None
    return value - None
    properties modified- Text fields and pick view
    precondition - None
    ******************************************************************************/
    func refreshUI() {
        songNameField.text = ""
        artistField.text = ""
        albumField.text = ""
        composerField.text = ""
        pickerView.reloadAllComponents()
    }
    /*******************************************************************************
    author: Tyler Creller
    Last Modified: Feb 24, 2015
    function switchToggle
    purpose - Check and update if switch is toggled
    parameters - Switch
    return value - none
    properties modified- pickView hidden status, defaults back to first row.
    precondition - Switch is toggled
    ******************************************************************************/
    @IBAction func switchToggle(sender: AnyObject) {
        if playlistSwitch.on{
            pickerView.hidden = false
        }
        else{
            pickerView.hidden = true
            pickerView.selectRow(0, inComponent: 0, animated: false)//Resets selected row to all songs when pickerView toggled off
        }
    }
    
    /*******************************************************************************
    author: All
    Last Modified: Feb 5, 2015
    function StepperValueChanged
    purpose - Check and update if stepper value was changed
    parameters - UIStepper
    return value - None
    properties modified- yearLabel is modified
    precondition - Stepper value is changed
    ******************************************************************************/
    @IBAction func StepperValueChanged(sender: UIStepper) {
        yearLabel.text = Int(sender.value).description
        
    }
    
    /*******************************************************************************
    author: All
    Last Modified: Feb 5, 2015
    function sliderValueChanged
    purpose - Check and update if slider value is changed
    parameters - UISlider
    return value - None
    properties modified- lengthLabel
    precondition - Slider is changed in value
    ******************************************************************************/
    @IBAction func sliderValueChange(sender: UISlider) {
        var currentValue = Int(sender.value)
        let (h,m,s) = secondsToHoursMinutesSeconds(currentValue)
        
        lengthLabel.text = "Len \(m):" + String(format: "%02d", s)
        
    }
    
    /*******************************************************************************
    author: Taylor Leblanc
    Last Modified: Feb 5, 2015
    function secondsToHoursMinutesSeconds
    purpose - Convert number of seconds into real time
    parameters - int: number of seconds in the song
    return value - hours, minutes, and seconds
    properties modified- None
    precondition - None
    ******************************************************************************/
    func secondsToHoursMinutesSeconds (seconds : Int) -> (Int, Int, Int) {
        return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
    
    }
    
    /*******************************************************************************
    author: Nathan Robinson, Daniel Ford, Tyler Creller
    Last Modified: Feb 24, 2015
    function addSongTapped
    purpose - Create a new song
    parameters - None
    return value - None
    properties modified- theSongModel.playlistArray
    precondition - Add Song button tapped
    ******************************************************************************/
    @IBAction func addSongTapped(sender: AnyObject){ //ERROR HANDLING, IF THEY TRY TO ADD WITHOUT INFORMATION, NOTIFY THEM TO FILL ALL FIELDS
            let (h,m,s) = secondsToHoursMinutesSeconds(Int(lengthSlider.value))
        
            var songResults = "\(songNameField.text) \(albumField.text) \(composerField.text) Len \(m):\(s) \(Int(yearStepper.value))"
            
            var artistResult = "\(artistField.text)"
            
            if !songNameField.text.isEmpty & !artistField.text.isEmpty & !albumField.text.isEmpty & !composerField.text.isEmpty {
                
                var thisSong = songModelAvacodo(title: songNameField.text, artist: artistField.text, album: albumField.text, length: "\(lengthSlider.value)", year: "\(yearStepper.value)", composer: composerField.text)
                theSongModel.playlistArray[0].add(thisSong)//Appends song to all songs playlist
                if theSongModel.playlistArray[pickerView.selectedRowInComponent(0)].name
                    != "All Songs"{
                    theSongModel.playlistArray[pickerView.selectedRowInComponent(0)].add(thisSong)
                }
            }
            else {
                //Call error function
                print("Thats not working")
            }
            refreshUI()
    }
    
    
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 24, 2015
    function viewDidLoad()
    purpose - Initially loads components in the view
    parameters - None
    return value - None
    properties modified- None
    precondition - View Loaded
    ******************************************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pickerView.delegate = self
        refreshUI()
    }
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 5, 2015
    function didReceiveMemoryWarning
    purpose - N/A
    parameters - None
    return value - None
    properties modified- None
    precondition - None
    ******************************************************************************/
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*******************************************************************************
    Functions below are all for configuring a pickerview
    
    author: Tyler Creller
    Last Modified: Feb 24, 2015
    function  - pickView functions
    purpose - Setup and reload pick view items
    parameters - UIPickerView
    return value - Various PickerView Attributes
    properties modified- PickerView
    precondition - Must have a PickerView
    ******************************************************************************/
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return theSongModel.playlistArray.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        return theSongModel.playlistArray[row].name
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        var itemSelected = theSongModel.playlistArray[row]
    }
    


}



