//
//  sharedSongModel.swift
//  singleton
//
//  Created by John Barr on 2/18/15.
//  Copyright (c) 2015 John Barr. All rights reserved.
//

import Foundation

private let _songModelSharedInstance = sharedSongModel()

class sharedSongModel {
    /*******************************************************************************
    // Class: sharedSongModel
    // Last modified: 2/24/2015
    //
    // playlistArray: An array to hold all playlist and song information
    ******************************************************************************/
    
    var playlistArray: [playlistModel]
    
    
    init(){
        playlistArray = [playlistModel(name:"All Songs", list: [])]
        playlistArray.append(playlistModel(name:"Jock Jamz", list: []))
    }
    
    class var theSharedSongModel: sharedSongModel {
        return _songModelSharedInstance
    }
}