//
//  searchTableViewController.swift
//  Sound Space by Sound Space
//
//  Created by lab on 2/25/15.
//  Copyright (c) 2015 Sound Space. All rights reserved.
//

import UIKit


class searchTableViewController : UITableViewController, UISearchBarDelegate, UISearchDisplayDelegate {
    
   
    var theSongModel: sharedSongModel = sharedSongModel.theSharedSongModel

    var filteredPlaylists = [playlistModel]()
    
    func filterContentForSearchText(searchText: String, scope:String="All") {
        //
        self.filteredPlaylists = self.theSongModel.playlistArray.filter({(playlist: playlistModel) -> Bool in
            //let categoryMatch = (scope == "All") || (playlist.name == scope)
            let stringMatch = playlist.name.rangeOfString(searchText)
            return stringMatch != nil
        })
    }
    
    func searchDisplayController(controller: UISearchDisplayController!, shouldReloadTableForSearchString
        searchString: String!) -> Bool {
            self.filterContentForSearchText(searchString)
            return true
    }

    /* THIS IS FOR SCOPE SEARCH
    func searchDisplayController(controller: UISearchDisplayController!,ShouldReloadTableForSearchScope
        searchOption: Int -> Bool {
        self.filterContentForSearchText(self.searchDisplayController!.searchBar.text)
        return true
    }
    */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.filteredPlaylists.append(playlistModel(name:"fuck", list: []))
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(theSongModel.playlistArray.count)
        if tableView == self.searchDisplayController!.searchResultsTableView {
            return self.filteredPlaylists.count
        }
        else {
            return self.theSongModel.playlistArray.count
        }
        //ONLY IMPLEMENTING PLAYLIST WILL BE CATEGORIZED LATER
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell
        
        var playlist: playlistModel
        
        if tableView == self.searchDisplayController!.searchResultsTableView {
            playlist = self.filteredPlaylists[indexPath.row]
        }
        else {
            playlist = self.theSongModel.playlistArray[indexPath.row]
        }
        

        //Get the corresponding playlist from playlistArray
        //let playlist = theSongModel.playlistArray[indexPath.row]
        // Configure the cell...
        print(theSongModel.playlistArray[indexPath.row].name)
        cell.textLabel!.text = self.theSongModel.playlistArray[indexPath.row].name
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
