//
//  playlistController.swift
//  Sound Space by Code Space
//
//
//  Created by Taylor LeBlanc, Nathan Robinson, Tyler Creller, Daniel Ford, Shai Ben-Dor on 2/4/15.
//  Copyright (c) 2015 Sound Space. All rights reserved.
//
//

import UIKit

class playlistController: UIViewController, UIPickerViewDelegate  {
    
    /*******************************************************************************
    // Class: playlistController
    // Last modified: 2/24/2015
    //
    // songView: A text view to display song information details
    // addPlaylist: A button that initiates the adding of a playlist when pressed
    // myPickerView: a UIPickerView that displays all playlists and songs in each playlist
    // theSongModel: Shared instance of all songs, see sharedSongModel.swift
    ******************************************************************************/
    
    @IBOutlet weak var songView: UITextView!
    @IBOutlet weak var addPlaylist: UIButton!
    @IBOutlet weak var myPickerView: UIPickerView!
    var theSongModel: sharedSongModel = sharedSongModel.theSharedSongModel
    
    /*******************************************************************************
    author: Nathan Robinson, Tyler Creller, Shai Ben-Dor, Daniel Ford
    Last Modified: Feb 23, 2015
    function present
    purpose - Present an alert with a textfield to allow a user to make a new playlist
    parameters - None
    return value - None
    properties modified - None
    precondition - Button is pressed to add a playlist
    ******************************************************************************/
    //add playlist popup and add playlist to picker
    @IBAction func present(sender: AnyObject) {
        let alertController = UIAlertController(title: "Create a New Playlist", message: "Enter a Name for the Playlist", preferredStyle: .Alert)
        var inputTextField: UITextField!
        let Add = UIAlertAction(title: "Add Playlist", style: .Default, handler: { (action) -> Void in
            var toAdd = playlistModel(name: "\(inputTextField!.text)", list: [])
            self.addPlaylistToArray(toAdd)})
        let cancel = UIAlertAction(title: "Cancel", style: .Cancel) {(action) -> Void in}
        alertController.addAction(Add)
        alertController.addAction(cancel)
        alertController.addTextFieldWithConfigurationHandler {(textField) -> Void in
            inputTextField = textField
        }
        presentViewController(alertController, animated: true, completion: nil)
    }

    /*******************************************************************************
    author: Nathan Robinson
    Last Modified: Feb 23, 2015
    function addPlaylist to Array
    purpose - add playlist to the array of playlists
    parameters - playlistModel(the playlist to be added)
    return value - None
    properties modified- theSongModel.playlistArray
    precondition - None
    ******************************************************************************/
    func addPlaylistToArray (playlist: playlistModel){
        theSongModel.playlistArray.append(playlist)
        refreshUI()
    }
    
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 24, 2015
    function refreshUI
    purpose - Reset and reload componenents in the view
    parameters - None
    return value - None
    properties modified- None
    precondition - None
    ******************************************************************************/
    func refreshUI() {
        myPickerView.reloadAllComponents()
    }
    
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 23, 2015
    function viewDidLoad()
    purpose - Initially loads components in the view
    parameters - None
    return value - None
    properties modified- None
    precondition - View Loaded
    ******************************************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshUI()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    /*******************************************************************************
    author: Default Function
    Last Modified: Feb 23, 2015
    function didReceiveMemoryWarning
    purpose - N/A
    parameters - None
    return value - None
    properties modified- None
    precondition - None
    ******************************************************************************/
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*******************************************************************************
    Functions below are all for configuring a pickerview
    
    author: Tyler Creller, Nathan Robinson, Daniel Ford, Shai Ben-Dor
    Last Modified: Feb 24, 2015
    function  - pickView functions
    purpose - Setup and reload pick view items
    parameters - UIPickerView
    return value - Various PickerView Attributes
    properties modified- PickerView
    precondition - Must have a PickerView
    ******************************************************************************/
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }

    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (component == 0){
            return theSongModel.playlistArray.count //Count number of playlists
        }
        else{
            return theSongModel.playlistArray[pickerView.selectedRowInComponent(0)].listAllSongs().count //Count number of songs in a selected playlist
        }
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        if (component == 0){
            return theSongModel.playlistArray[row].name //Playlist names
        }
        else if (component == 1){
            return theSongModel.playlistArray[pickerView.selectedRowInComponent(0)].accessSong(row)?.title //Song names for each play list
        }
        return nil
    }

    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        refreshUI()
        var itemSelected = theSongModel.playlistArray[row]
        /*songView.text = ""
        songView.text.extend("Song      Artist      Album      Composer      Year\n")
        for item in itemSelected.listAllSongs(){                                            //Uncommenting this will allow for writing to the textview
            songView.text.extend("\(item.title)  \(item.artist)\n")
        }*/
    }
    

    
}

